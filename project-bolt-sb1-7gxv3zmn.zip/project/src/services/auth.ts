import { LoginCredentials, User } from '../types/auth';

export async function login(credentials: LoginCredentials): Promise<User> {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        id: '1',
        username: credentials.username,
        email: `${credentials.username}@example.com`,
        name: 'John Doe'
      });
    }, 1000);
  });
}

export async function sendPasswordResetOTP(email: string): Promise<void> {
  // Simulate sending OTP
  return new Promise((resolve) => {
    setTimeout(resolve, 1000);
  });
}

export async function verifyOTPAndResetPassword(
  email: string,
  otp: string,
  newPassword: string
): Promise<void> {
  // Simulate password reset
  return new Promise((resolve) => {
    setTimeout(resolve, 1000);
  });
}