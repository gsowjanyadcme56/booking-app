import { PaymentMethod, PaymentTransaction, RefundRequest } from '../types/payment';

export async function processPayment(
  bookingId: string,
  amount: number,
  paymentMethod: PaymentMethod
): Promise<PaymentTransaction> {
  // Simulate payment processing
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        id: Date.now().toString(),
        bookingId,
        amount,
        status: 'COMPLETED',
        paymentMethod,
        timestamp: new Date().toISOString()
      });
    }, 1500);
  });
}

export async function processRefund(request: RefundRequest): Promise<PaymentTransaction> {
  // Simulate refund processing
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        id: Date.now().toString(),
        bookingId: request.bookingId,
        amount: request.amount,
        status: 'REFUNDED',
        paymentMethod: { id: '', type: 'UPI', details: {} },
        timestamp: new Date().toISOString()
      });
    }, 1500);
  });
}