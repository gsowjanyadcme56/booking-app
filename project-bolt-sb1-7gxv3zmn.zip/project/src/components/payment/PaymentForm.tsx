import React, { useState } from 'react';
import { CreditCard, Smartphone, Building } from 'lucide-react';
import { PaymentMethod } from '../../types/payment';

interface PaymentFormProps {
  amount: number;
  onPaymentSubmit: (paymentMethod: PaymentMethod) => void;
}

export function PaymentForm({ amount, onPaymentSubmit }: PaymentFormProps) {
  const [paymentType, setPaymentType] = useState<PaymentMethod['type']>('UPI');
  const [upiId, setUpiId] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [bankName, setBankName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const paymentMethod: PaymentMethod = {
      id: Date.now().toString(),
      type: paymentType,
      details: {
        upiId: paymentType === 'UPI' ? upiId : undefined,
        lastFourDigits: paymentType === 'CARD' ? cardNumber.slice(-4) : undefined,
        bankName: paymentType === 'NET_BANKING' ? bankName : undefined,
      },
    };
    onPaymentSubmit(paymentMethod);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">Payment Details</h2>
      <div className="mb-6">
        <p className="text-lg">Total Amount: <span className="font-bold">₹{amount}</span></p>
      </div>

      <div className="mb-6">
        <div className="flex space-x-4">
          <button
            type="button"
            onClick={() => setPaymentType('UPI')}
            className={`flex-1 p-4 rounded-lg border ${
              paymentType === 'UPI' ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
            }`}
          >
            <Smartphone className="w-6 h-6 mx-auto mb-2" />
            <span>UPI</span>
          </button>
          <button
            type="button"
            onClick={() => setPaymentType('CARD')}
            className={`flex-1 p-4 rounded-lg border ${
              paymentType === 'CARD' ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
            }`}
          >
            <CreditCard className="w-6 h-6 mx-auto mb-2" />
            <span>Card</span>
          </button>
          <button
            type="button"
            onClick={() => setPaymentType('NET_BANKING')}
            className={`flex-1 p-4 rounded-lg border ${
              paymentType === 'NET_BANKING' ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
            }`}
          >
            <Building className="w-6 h-6 mx-auto mb-2" />
            <span>Net Banking</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {paymentType === 'UPI' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              UPI ID
            </label>
            <input
              type="text"
              value={upiId}
              onChange={(e) => setUpiId(e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
              placeholder="username@upi"
              required
            />
          </div>
        )}

        {paymentType === 'CARD' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Card Number
            </label>
            <input
              type="text"
              value={cardNumber}
              onChange={(e) => setCardNumber(e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
              placeholder="1234 5678 9012 3456"
              required
            />
          </div>
        )}

        {paymentType === 'NET_BANKING' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Select Bank
            </label>
            <select
              value={bankName}
              onChange={(e) => setBankName(e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
              required
            >
              <option value="">Select a bank</option>
              <option value="SBI">State Bank of India</option>
              <option value="HDFC">HDFC Bank</option>
              <option value="ICICI">ICICI Bank</option>
              <option value="Axis">Axis Bank</option>
            </select>
          </div>
        )}

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition-colors"
        >
          Pay ₹{amount}
        </button>
      </form>
    </div>
  );
}