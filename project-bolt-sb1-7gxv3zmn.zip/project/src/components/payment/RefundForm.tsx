import React, { useState } from 'react';
import { RefundRequest } from '../../types/payment';

interface RefundFormProps {
  bookingId: string;
  amount: number;
  onRefundSubmit: (request: RefundRequest) => void;
}

export function RefundForm({ bookingId, amount, onRefundSubmit }: RefundFormProps) {
  const [reason, setReason] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onRefundSubmit({
      bookingId,
      reason,
      amount
    });
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-6">Request Refund</h2>
      <div className="mb-6">
        <p className="text-lg">Refund Amount: <span className="font-bold">₹{amount}</span></p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Reason for Refund
          </label>
          <textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full px-3 py-2 border rounded-md"
            rows={4}
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition-colors"
        >
          Submit Refund Request
        </button>
      </form>
    </div>
  );
}