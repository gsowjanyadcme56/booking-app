import React, { useState } from 'react';
import { X } from 'lucide-react';
import { BusTrip } from '../types';

interface BookingModalProps {
  trip: BusTrip;
  onClose: () => void;
  onBook: (booking: {
    seatNumbers: string[];
    customerName: string;
    customerEmail: string;
    customerPhone: string;
  }) => void;
}

export function BookingModal({ trip, onClose, onBook }: BookingModalProps) {
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');

  const handleSeatToggle = (seatNumber: string) => {
    setSelectedSeats(prev =>
      prev.includes(seatNumber)
        ? prev.filter(seat => seat !== seatNumber)
        : [...prev, seatNumber]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onBook({
      seatNumbers: selectedSeats,
      customerName,
      customerEmail,
      customerPhone
    });
  };

  const renderSeats = () => {
    const seats = [];
    const totalRows = Math.ceil(trip.bus.totalSeats / 4);

    for (let row = 0; row < totalRows; row++) {
      const rowSeats = [];
      for (let col = 0; col < 4; col++) {
        const seatNumber = row * 4 + col + 1;
        if (seatNumber <= trip.bus.totalSeats) {
          const isSelected = selectedSeats.includes(seatNumber.toString());
          rowSeats.push(
            <button
              key={seatNumber}
              onClick={() => handleSeatToggle(seatNumber.toString())}
              className={`w-10 h-10 m-1 rounded-md ${
                isSelected
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 hover:bg-gray-200'
              }`}
              disabled={seatNumber > trip.availableSeats}
            >
              {seatNumber}
            </button>
          );
        }
      }
      seats.push(
        <div key={row} className="flex justify-center gap-4">
          {rowSeats.slice(0, 2)}
          <div className="w-8" /> {/* Aisle */}
          {rowSeats.slice(2)}
        </div>
      );
    }
    return seats;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
        >
          <X className="w-6 h-6" />
        </button>

        <h2 className="text-2xl font-bold mb-4">Select Seats</h2>
        
        <div className="mb-6">
          <div className="text-center mb-4">
            <p className="font-medium">{trip.route.from} → {trip.route.to}</p>
            <p className="text-gray-600">{trip.date} | {trip.route.departureTime}</p>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            <div className="flex justify-center mb-4">
              <div className="w-20 h-2 bg-gray-300 rounded-full" /> {/* Bus front */}
            </div>
            {renderSeats()}
          </div>

          <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
            <div>
              <p>Selected Seats: {selectedSeats.join(', ') || 'None'}</p>
              <p className="text-sm text-gray-600">Price per seat: ₹{trip.price}</p>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold">
                Total: ₹{(selectedSeats.length * trip.price).toFixed(2)}
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Full Name
            </label>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email
            </label>
            <input
              type="email"
              value={customerEmail}
              onChange={(e) => setCustomerEmail(e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Phone Number
            </label>
            <input
              type="tel"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
              required
            />
          </div>

          <button
            type="submit"
            disabled={selectedSeats.length === 0}
            className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition-colors disabled:bg-gray-400"
          >
            Book Tickets
          </button>
        </form>
      </div>
    </div>
  );
}