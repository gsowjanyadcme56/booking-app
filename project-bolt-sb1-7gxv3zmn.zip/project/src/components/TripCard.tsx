import React from 'react';
import { Bus, Clock, MapPin } from 'lucide-react';
import { BusTrip } from '../types';

interface TripCardProps {
  trip: BusTrip;
  onBookSeats: (tripId: string) => void;
}

export function TripCard({ trip, onBookSeats }: TripCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-xl font-bold mb-2">{trip.route.from} → {trip.route.to}</h3>
          <div className="flex items-center text-gray-600 mb-1">
            <Clock className="w-4 h-4 mr-2" />
            <span>{trip.route.departureTime} - {trip.route.arrivalTime}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <MapPin className="w-4 h-4 mr-2" />
            <span>{trip.route.distance}</span>
          </div>
        </div>
        <div className="text-right">
          <span className="inline-block px-3 py-1 rounded-full text-sm font-medium mb-2"
            style={{
              backgroundColor: trip.bus.type.includes('AC') ? '#e0f2fe' : '#f3f4f6',
              color: trip.bus.type.includes('AC') ? '#0369a1' : '#4b5563'
            }}>
            {trip.bus.type}
          </span>
        </div>
      </div>

      <div className="border-t border-gray-200 pt-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center text-gray-600">
            <Bus className="w-4 h-4 mr-2" />
            <span>{trip.bus.busNumber}</span>
          </div>
          <span className="text-gray-600">{trip.availableSeats} seats left</span>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <span className="text-sm text-gray-500">Price per seat</span>
            <p className="text-2xl font-bold text-blue-600">₹{trip.price}</p>
          </div>
          <button
            onClick={() => onBookSeats(trip.id)}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            disabled={trip.availableSeats === 0}
          >
            {trip.availableSeats === 0 ? 'Sold Out' : 'Select Seats'}
          </button>
        </div>
      </div>
    </div>
  );
}