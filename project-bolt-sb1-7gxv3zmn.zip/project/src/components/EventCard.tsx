import React from 'react';
import { Calendar, MapPin, Ticket } from 'lucide-react';
import { Event } from '../types';

interface EventCardProps {
  event: Event;
  onBookTickets: (eventId: string) => void;
}

export function EventCard({ event, onBookTickets }: EventCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:scale-[1.02]">
      <img
        src={event.imageUrl}
        alt={event.title}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <h3 className="text-xl font-bold mb-2">{event.title}</h3>
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-gray-600">
            <Calendar className="w-4 h-4 mr-2" />
            <span>{event.date} at {event.time}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <MapPin className="w-4 h-4 mr-2" />
            <span>{event.location}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Ticket className="w-4 h-4 mr-2" />
            <span>{event.availableSeats} seats available</span>
          </div>
        </div>
        <p className="text-gray-600 mb-4">{event.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold">${event.price}</span>
          <button
            onClick={() => onBookTickets(event.id)}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Book Tickets
          </button>
        </div>
      </div>
    </div>
  );
}