export interface Bus {
  id: string;
  busNumber: string;
  type: 'AC Sleeper' | 'AC Seater' | 'Non-AC Sleeper' | 'Non-AC Seater';
  totalSeats: number;
}

export interface Route {
  id: string;
  from: string;
  to: string;
  departureTime: string;
  arrivalTime: string;
  distance: string;
}

export interface BusTrip {
  id: string;
  busId: string;
  routeId: string;
  date: string;
  price: number;
  availableSeats: number;
  bus: Bus;
  route: Route;
}

export interface Booking {
  id: string;
  tripId: string;
  seatNumbers: string[];
  totalPrice: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
}