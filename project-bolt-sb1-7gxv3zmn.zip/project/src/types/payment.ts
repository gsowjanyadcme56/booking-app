export interface PaymentMethod {
  id: string;
  type: 'UPI' | 'CARD' | 'NET_BANKING';
  details: {
    bankName?: string;
    upiId?: string;
    lastFourDigits?: string;
  };
}

export interface PaymentTransaction {
  id: string;
  bookingId: string;
  amount: number;
  status: 'PENDING' | 'COMPLETED' | 'FAILED' | 'REFUNDED';
  paymentMethod: PaymentMethod;
  timestamp: string;
}

export interface RefundRequest {
  bookingId: string;
  reason: string;
  amount: number;
}