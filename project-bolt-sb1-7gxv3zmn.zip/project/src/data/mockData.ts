import { Bus, Route, BusTrip } from '../types';

export const buses: Bus[] = [
  {
    id: '1',
    busNumber: 'KA-01-HD-1234',
    type: 'AC Sleeper',
    totalSeats: 36
  },
  {
    id: '2',
    busNumber: 'TN-07-BR-5678',
    type: 'AC Seater',
    totalSeats: 45
  },
  {
    id: '3',
    busNumber: 'MH-04-KL-9012',
    type: 'Non-AC Sleeper',
    totalSeats: 36
  },
  {
    id: '4',
    busNumber: 'KL-10-AB-3456',
    type: 'Non-AC Seater',
    totalSeats: 50
  }
];

export const routes: Route[] = [
  {
    id: '1',
    from: 'Bangalore',
    to: 'Mumbai',
    departureTime: '18:00',
    arrivalTime: '10:00',
    distance: '985 km'
  },
  {
    id: '2',
    from: 'Delhi',
    to: 'Jaipur',
    departureTime: '20:00',
    arrivalTime: '04:30',
    distance: '280 km'
  },
  {
    id: '3',
    from: 'Chennai',
    to: 'Hyderabad',
    departureTime: '19:30',
    arrivalTime: '08:00',
    distance: '625 km'
  },
  {
    id: '4',
    from: 'Mumbai',
    to: 'Goa',
    departureTime: '21:00',
    arrivalTime: '09:30',
    distance: '590 km'
  },
  {
    id: '5',
    from: 'Bangalore',
    to: 'Chennai',
    departureTime: '22:30',
    arrivalTime: '06:00',
    distance: '345 km'
  },
  {
    id: '6',
    from: 'Hyderabad',
    to: 'Bangalore',
    departureTime: '21:30',
    arrivalTime: '08:00',
    distance: '570 km'
  }
];

export const busTrips: BusTrip[] = [
  {
    id: '1',
    busId: '1',
    routeId: '1',
    date: '2024-03-20',
    price: 2499,
    availableSeats: 36,
    bus: buses[0],
    route: routes[0]
  },
  {
    id: '2',
    busId: '2',
    routeId: '2',
    date: '2024-03-20',
    price: 1299,
    availableSeats: 45,
    bus: buses[1],
    route: routes[1]
  },
  {
    id: '3',
    busId: '3',
    routeId: '3',
    date: '2024-03-20',
    price: 1899,
    availableSeats: 36,
    bus: buses[2],
    route: routes[2]
  },
  {
    id: '4',
    busId: '4',
    routeId: '4',
    date: '2024-03-20',
    price: 1699,
    availableSeats: 50,
    bus: buses[3],
    route: routes[3]
  },
  {
    id: '5',
    busId: '1',
    routeId: '5',
    date: '2024-03-20',
    price: 999,
    availableSeats: 36,
    bus: buses[0],
    route: routes[4]
  },
  {
    id: '6',
    busId: '2',
    routeId: '6',
    date: '2024-03-20',
    price: 1599,
    availableSeats: 45,
    bus: buses[1],
    route: routes[5]
  }
];