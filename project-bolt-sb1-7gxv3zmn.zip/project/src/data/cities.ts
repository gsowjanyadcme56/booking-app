export const cities = [
  'Bangalore',
  'Chennai',
  'Delhi',
  'Goa',
  'Hyderabad',
  'Jaipur',
  'Kochi',
  'Kolkata',
  'Mumbai',
  'Pune'
].sort();