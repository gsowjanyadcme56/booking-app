import React, { useState } from 'react';
import { Bus } from 'lucide-react';
import { SearchForm } from './components/SearchForm';
import { TripCard } from './components/TripCard';
import { BookingModal } from './components/BookingModal';
import { BusTrip } from './types';
import { busTrips } from './data/mockData';

function App() {
  const [selectedTrip, setSelectedTrip] = useState<BusTrip | null>(null);
  const [filteredTrips, setFilteredTrips] = useState<BusTrip[]>(busTrips);

  const handleSearch = (search: { from: string; to: string; date: string }) => {
    const filtered = busTrips.filter(trip =>
      trip.route.from.toLowerCase().includes(search.from.toLowerCase()) &&
      trip.route.to.toLowerCase().includes(search.to.toLowerCase()) &&
      trip.date === search.date
    );
    setFilteredTrips(filtered);
  };

  const handleBookingSubmit = (booking: {
    seatNumbers: string[];
    customerName: string;
    customerEmail: string;
    customerPhone: string;
  }) => {
    // Here you would typically handle the booking submission
    console.log('Booking submitted:', booking);
    alert('Booking successful! Check your email for confirmation.');
    setSelectedTrip(null);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center">
            <Bus className="w-8 h-8 text-blue-600 mr-2" />
            <h1 className="text-2xl font-bold text-gray-900">BusBooking</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <SearchForm onSearch={handleSearch} />
        </div>

        <div className="space-y-6">
          {filteredTrips.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No trips found for your search criteria.</p>
            </div>
          ) : (
            filteredTrips.map((trip) => (
              <TripCard
                key={trip.id}
                trip={trip}
                onBookSeats={() => setSelectedTrip(trip)}
              />
            ))
          )}
        </div>
      </main>

      {selectedTrip && (
        <BookingModal
          trip={selectedTrip}
          onClose={() => setSelectedTrip(null)}
          onBook={handleBookingSubmit}
        />
      )}
    </div>
  );
}

export default App;